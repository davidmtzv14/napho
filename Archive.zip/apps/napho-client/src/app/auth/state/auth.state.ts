import { User } from '@napho/data';

export interface AuthState {
  user: Partial<User>;
}
